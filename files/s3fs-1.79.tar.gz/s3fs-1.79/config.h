/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* short commit hash value on github */
#define COMMIT_HASH_VAL "d6e6eeb"

/* Define to 1 if you have the `clock_gettime' function. */
#define HAVE_CLOCK_GETTIME 1

/* Define to 1 if you have the `malloc_trim' function. */
#define HAVE_MALLOC_TRIM 1

/* Name of package */
#define PACKAGE "s3fs"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "s3fs"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "s3fs 1.79"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "s3fs"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.79"

/* Define if you have PTHREAD_MUTEX_RECURSIVE_NP */
#define S3FS_MUTEX_RECURSIVE PTHREAD_MUTEX_RECURSIVE

/* Version number of package */
#define VERSION "1.79"
